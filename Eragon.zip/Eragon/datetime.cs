﻿/* Decrypts Chrome V80 and above password and cookies. 
*  but currently displays in console
*  Written By Dextertech
*  Twitter: DextertechV
*  Discord: DexterTech111#7106

	Although not well documented as there was no demand for this project
	and i was in a hurry. download visual studio, open solution and enjoy!
	
	Disclaimer: this code is for educational purposes only and i will not
	be held liable for any misuse of this code.
*/
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Eragon
{
    class datetime
    {
        public string showDate()
        {
            DateTime dt = DateTime.Now;
            return dt.ToString("r", DateTimeFormatInfo.InvariantInfo);
        }
    }
}
